import fs from "fs";
import fsp from "fs/promises";
import path from "path";

const ROOT_DIR =
  process.env.FILEMANAGER_ROOT_DIR ||
  path.resolve(process.cwd(), "storage");

if (!fs.existsSync(ROOT_DIR)) {
  fs.mkdirSync(ROOT_DIR, { recursive: true });
}

function resolveSafePath(rel: string | null): string {
  const relPath = rel || "/";
  const normalized = path
    .normalize(relPath)
    .replace(/^(\.\.(\/|\\|$))+/, "")
    .replace(/^\/+/, "");

  const abs = path.join(ROOT_DIR, normalized);
  const root = ROOT_DIR.endsWith(path.sep) ? ROOT_DIR : ROOT_DIR + path.sep;
  if (!abs.startsWith(root)) {
    throw new Error("Invalid path");
  }
  return abs;
}

export async function listDir(rel: string | null) {
  const dirPath = resolveSafePath(rel);
  const entries = await fsp.readdir(dirPath, { withFileTypes: true });

  const result = await Promise.all(
    entries.map(async (ent) => {
      const full = path.join(dirPath, ent.name);
      const stat = await fsp.stat(full);
      return {
        name: ent.name,
        isDir: ent.isDirectory(),
        size: stat.size,
        mtime: stat.mtime.toISOString(),
      };
    })
  );

  return {
    path: rel || "/",
    items: result,
  };
}

export async function saveFile(relDir: string | null, file: File) {
  const dirPath = resolveSafePath(relDir);
  await fsp.mkdir(dirPath, { recursive: true });

  const arrayBuffer = await file.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);
  const dest = path.join(dirPath, file.name);

  await fsp.writeFile(dest, buffer);

  return { ok: true, name: file.name };
}

export async function deleteEntry(relPath: string) {
  const full = resolveSafePath(relPath);
  const stat = await fsp.stat(full);

  if (stat.isDirectory()) {
    await fsp.rm(full, { recursive: true, force: true });
  } else {
    await fsp.unlink(full);
  }

  return { ok: true };
}