import { NextRequest, NextResponse } from "next/server";
import { listDir, saveFile, deleteEntry } from "@/lib/filemanager";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const rel = searchParams.get("path");
    const data = await listDir(rel);
    return NextResponse.json(data);
  } catch (err: any) {
    return NextResponse.json({ error: err?.message || "Error listing" }, { status: 400 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const contentType = req.headers.get("content-type") || "";
    if (!contentType.includes("multipart/form-data")) {
      return NextResponse.json({ error: "Use multipart/form-data" }, { status: 400 });
    }

    const formData = await req.formData();
    const file = formData.get("file") as File | null;
    const path = (formData.get("path") as string | null) || "/";

    if (!file) {
      return NextResponse.json({ error: "No file uploaded" }, { status: 400 });
    }

    const result = await saveFile(path, file);
    return NextResponse.json(result);
  } catch (err: any) {
    return NextResponse.json({ error: err?.message || "Upload failed" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const body = await req.json();
    const relPath = body?.path as string | undefined;

    if (!relPath) {
      return NextResponse.json({ error: "path is required" }, { status: 400 });
    }

    const result = await deleteEntry(relPath);
    return NextResponse.json(result);
  } catch (err: any) {
    return NextResponse.json({ error: err?.message || "Delete failed" }, { status: 500 });
  }
}