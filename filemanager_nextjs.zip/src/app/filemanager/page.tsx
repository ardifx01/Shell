"use client";

import React, { useEffect, useState } from "react";

type Item = {
  name: string;
  isDir: boolean;
  size: number;
  mtime: string;
};

export default function FileManagerPage() {
  const [currentPath, setCurrentPath] = useState<string>("/");
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);

  async function load(path: string) {
    setLoading(true);
    const params = new URLSearchParams();
    if (path && path !== "/") params.set("path", path);

    const res = await fetch(`/api/filemanager?${params.toString()}`);
    const data = await res.json();

    setCurrentPath(data.path || "/");
    setItems(data.items || []);
    setLoading(false);
  }

  useEffect(() => {
    load("/");
  }, []);

  async function handleUpload(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const input = e.currentTarget.file as HTMLInputElement;
    if (!input.files || !input.files[0]) return;

    const fd = new FormData();
    fd.append("file", input.files[0]);
    fd.append("path", currentPath);

    setUploading(true);
    await fetch("/api/filemanager", { method: "POST", body: fd });
    setUploading(false);
    load(currentPath);
  }

  return (
    <div style={{ padding: "1.5rem" }}>
      <h1>File Manager</h1>
      <form onSubmit={handleUpload}>
        <input type="file" name="file" />
        <button type="submit" disabled={uploading}>
          Upload
        </button>
      </form>

      {loading && <div>Loading...</div>}

      <ul>
        {items.map((it) => (
          <li key={it.name}>
            {it.isDir ? "📁" : "📄"} {it.name}
          </li>
        ))}
      </ul>
    </div>
  );
}